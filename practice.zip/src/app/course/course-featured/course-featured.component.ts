import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-featured',
  templateUrl: './course-featured.component.html',
  styleUrls: ['./course-featured.component.css']
})
export class CourseFeaturedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
