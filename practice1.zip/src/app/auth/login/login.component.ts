import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup,FormControl,Validator, Validators } from "@angular/forms";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  // // form:FormGroup;
  // username = new FormControl('')       this is for single Form control 
  // password = new FormControl('')

 login:FormGroup;
 
  constructor(private fb:FormBuilder) { }

  ngOnInit() {
    this.elogin()
  }
  elogin(){
    this.login = this.fb.group({
      username:['',Validators.required],
      password:['',Validators.required]
    })
  }
  
  get username(){
    return this.login.get('username')
  }
  get password(){
    return this.login.get('password')
  }
  onSubmit(){
    console.log(this.login.value)
  }

}
